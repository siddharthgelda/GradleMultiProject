package com;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProductService {

	public Product getUser()
	{
		Product u=new Product();
		u.setId(1L);
		u.setName("test");
		return u;
	}
}
