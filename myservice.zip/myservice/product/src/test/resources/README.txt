Place 'resources' that need to be added to your project's classpath in this folder.
If you don't have any such resources. You can delete this folder and then do 'refresh 
source folders' from the Gradle menu to remove it from the Gradle model and Eclipse 
classpath.