package com;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserService {

	public User getUser()
	{
		User u=new User();
		u.setId(1L);
		u.setName("test");
		return u;
	}
}
